'''Open binary/ASCII STL, Wavefront OBJ, ASCII OFF, binary/ASCII PLY, XAML format files'''
'''Please donot use 'uint', 'uint8' and 'uint16' formats in the point cloud files'''
'''Team SAAS, Ekalavya 2017'''

#import the necessary packages
import numpy as np
import trimesh
import os

print "Please give the file path"
path=raw_input() #path of the file to be opened is given
newpath=path.replace('.ply','copy.ply') #a new path for making the copy of the file is created
o=open(path,'r') #file is opened for reading
data=o.read() #all the data inside the file is saved in form of a string 
o.close() #the file is closed

#this step is done to fix a bug with trimesh. trimesh 2.11 has some issues with the uint8 data type.
#hence the uint8 and uint16 data types are being converted into float32 
try:
	data=data.replace('uint8','float32')
except:
	pass
try:
	data=data.replace('uint16','float32')
except:
	pass

#this step writes the data into a temporary buffer file that is used only during the execution of the program
f=open(newpath,'w')
f.write(data)
f.close()

mesh = trimesh.load_mesh(newpath)# load a mesh file from its path
mesh.vertices -= mesh.center_mass # to set the volumetric center of mass as the origin of the object
mesh.show()

os.remove(newpath) # the temporary file is removed
