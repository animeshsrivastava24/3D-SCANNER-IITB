'''Plot the point cloud from any .ply file with ASCII encoding using matplotlib and mplot3d'''
'''Team SAAS, Ekalavya 2017, IIT Bombay'''


#import the necessary packages
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import LinearLocator
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
path=raw_input("Enter the path of the file\n") #path for opening the file is asked to the user

X=[]
Y=[]
Z=[]
StartIndex=0

f=open(path,'r')
lines=f.readlines()
f.close()

#coordinates of the point cloud vertices are extracted from the file
for i in lines:
	temp=i.split(' ')
	if (temp[0]=='element'):
		if (temp[1]=='vertex'):
			vertices=long(int(temp[2]))
		if (temp[1]=='face'):
			face=long(int(temp[2]))
print "The given file has %d number of vertices and %d number of faces" %(vertices,face)

coordinates=[]

for i in range(len(lines)):
	temp=lines[i]
	if (temp=='end_header\n'):
		StartIndex=i+1
		break

for i in range(StartIndex,(StartIndex+vertices)):
			coordinates.append(lines[i])

#the coordinates are appended in the list X, Y, Z
for i in coordinates:
	point=i.split(' ')
	X.append(float(point[0]))
	Y.append(float(point[1]))
	Z.append(float(point[2]))

#a scatter plot is created
surf = ax.scatter(X, Y, Z, zdir='y') 

#a window is created showing the scatter plot
plt.show()

